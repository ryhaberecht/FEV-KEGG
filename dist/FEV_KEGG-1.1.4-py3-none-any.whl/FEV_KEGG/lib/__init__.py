"""
This package contains code copied from other projects, because either parts of it were changed, or the original import would have been unnecessarily big.
"""