"""
This package contains functions full of assumptions about specific, yet simple and varying models of evolution.
None of the results should be viewed as unconditional truth!
"""