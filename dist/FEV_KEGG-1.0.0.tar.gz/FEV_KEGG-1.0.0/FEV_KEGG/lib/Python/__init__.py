"""
Code from Python, copied because of some small changes in behaviour of :class:`ProcessPoolExecutor`.

Note
----
.. include:: ../../FEV_KEGG/lib/Python/LICENSE.rst

"""