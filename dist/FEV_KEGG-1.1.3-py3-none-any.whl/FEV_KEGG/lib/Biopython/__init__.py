"""
Code from `Biopython`, copied because the whole import would have been unnecessarily big.

The code was changed in some spots to enable it to run independently.
Also, the timeout parameter of the underlying socket was exposed.

Note
----
.. include:: ../../FEV_KEGG/lib/Biopython/LICENSE.rst

"""